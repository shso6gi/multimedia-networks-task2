#include "opencp.hpp"

using namespace std;
using namespace cv;